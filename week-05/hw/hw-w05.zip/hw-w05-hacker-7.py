# Enter your code here. Read input from STDIN. Print output to STDOUT
a = int(input())
b = int(input())

print(a // b)
print(a % b)
print(divmod(a,b))